// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers','angular-storage'])

.run(function($ionicPlatform) {
    $ionicPlatform.ready(function() {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);

        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }
    });
})

.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider

    .state('app', {
        url: '/app',
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
    })

    .state('app.login', {
        url: '/login',
        cache : false,
        views: {
            'menuContent': {
                templateUrl: 'templates/login.html',
                controller: 'logincontroller'
            }
        }
    })

    .state('app.browse', {
        url: '/browse',
        cache : false,
        views: {
            'menuContent': {
                templateUrl: 'templates/browse.html',
                controller: 'listCtrl'
            }
        }
    })

    .state('app.Browse_truck', {
        url: '/Browse_truck',
        views: {
            'menuContent': {
                templateUrl: 'templates/Browse_truck.html',
                controller: 'AgencyCtrl'
            }
        }
    })


    .state('app.agencylist_details', {
        url: '/agencylist_details',
        views: {
            'menuContent': {
                templateUrl: 'templates/agencylist_details.html',
                controller: 'detailsCtrl'
            }
        }
    })


    .state('app.take_photo', {
        url: '/take_photo',
        views: {
            'menuContent': {
                templateUrl: 'templates/take_photo.html',
                controller: ''
            }
        }
    })

    .state('app.agency_location', {
            url: '/agency_location',
            views: {
                'menuContent': {
                    templateUrl: 'templates/agency_location.html',
                    controller: ''
                }
            }
        })
        .state('app.truck_details', {
            url: '/truck_details',
            views: {
                'menuContent': {
                    templateUrl: 'templates/truck_details.html',
                    controller: 'AgencyCtrl'
                }
            }
        });




    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/login');
});
